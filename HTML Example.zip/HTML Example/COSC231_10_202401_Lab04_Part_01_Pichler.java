package pichlerLab04;

/*
Class: COSC 231.10
Name:  Chris Pichler
EID:   E02760792
Lab:   04(Part 01)
Date:  2023-09-30 SAT T 23:59:00 Z-04:00

Requires: input sub-directory ./input/ containing source input
file; output sub-directory ./output (with write permission for
output HTML file this code creates). Another requirement may be
that this source code needs to be in a Java project folder with the
same name as this class inside of a Java package with the same name 
as this class.

Description: In this project, we are creating 4 HTML files containing information from
12 .CSV files and creating it in a way that is readable for the user.
 */

//NOTE FOR PROFESSOR: I know this works when I run it inside of a Java project inside of a package on Eclipse.
//It might be possible I need more or less "..\\" in the file name if not run in a package, but when I run
//it on my device in Eclipse, it does everything correctly. 


//import java.io.* for file reading, and java.util.* for the Scanner
import java.io.*;
import java.util.*;

public class COSC231_10_202401_Lab04_Part_01_Pichler{
	//The main method throws an Exception in order to effectively create File objects
	public static void main(String[] args) throws Exception{
		int m = 1;
		int i = 0;
		
		//String post is for creating the numbers for the file names for input and output
		String post;
		
		//This Scanner object will read data from the input file
		Scanner scnr;
		
		
		do {
			//This is the beginning of the file name for each input file
			String fileName = "wolf_creek_hourly_2019_";
			if(m < 10) {
				post = "0" + (m + "");
			}
			else {
				post = m + "";
			}

			//Create the File object for the input file
			//java.io.File file = new java.io.File("C:\\Users\\pingp\\Desktop\\EMU Computer Science\\COSC 231\\COSC231_10_202401_Lab_04_Part_01_Pichler\\input\\wolf_creek_hourly_2019_" + post + ".csv");
			java.io.File file = new java.io.File("..\\Lab_4\\input\\wolf_creek_hourly_2019_" + post + ".csv");
			//Create the Scanner object for the reading from the input file
			scnr = new Scanner(file);
			
			//Create the File object for the output file
			java.io.File outputFile = new java.io.File("..\\Lab_4\\output\\2019_" + post + ".html");
			
			//Create a PrintWriter obejct to write to the output file
			java.io.PrintWriter output = new java.io.PrintWriter(outputFile);
			
			//Begin writing to the HTML file
			output.println("<html>");
			output.println("<head>");
			output.println("<!-- Class COSC 231.10\nName: Chris Pichler\nEID: E02760792\nLab: 04 (Part 02)\n Date: 2023-10-05 THU T 23:59:00 Z-04:00\n\nRequries: css folder in same directory as HTML pages with wolfcreek.css styling rules in the css folder. This was created in Java, so there is no indentation in the HTML code of the 12 HTML pages. There is indentation in the CSS document and the index.html page.-->");
			output.println("<meta charset=\"UTF-8\">");
			output.println("</head>");
			output.print("<title>");
			output.print("WolfCreek Dam: 2019-" + post);
			output.println("</title>");
			output.println("<!-- This is the reference to the wolfcreek.css stylesheet that will define how to style all 12 HTML pages -->");
			output.println("<link rel=\"stylesheet\" href=\"css\\wolfcreek.css\">");
			output.print("<style>");
			output.println("</style>");
			output.print("<script>");
			output.println("</script>");
			output.println("<body>");
			output.println("<div id=\"top\">");
			output.println("</div>");
			output.println("<!-- This is the menu div that will display the top menu of each HTML page -->");
			output.println("<div id=\"navmenu_div\" class=\"navbarouter\"></div>");
			//output.println("<button id=\"nav_button\">Hide Menu");
			output.println("<div id=\"navmenu_div\" class=\"navbarouter\">\r\n"
					+ "		<button id=\"nav_button\">Hide Menu</button> \r\n"
					+ "		<div id=\"navbar\" class=\"navbar\">\r\n"
					+ "			<div class=\"nav_list\"><p>Maps &amp; Charts:</p></div>\r\n"
					+ "			<div class=\"nav_list\">	\r\n"
					+ "				<a href=\"index.html\">Main</a>\r\n"
					+ "			</div>	\r\n"
					+ "			<div class=\"nav_list\"><p>Hourly Readings by Month:</p></div>\r\n"
					+ "			<div class=\"nav_list\">\r\n"
					+ "				<a href=\"2019_01.html\">2019-01</a><a href=\"2019_02.html\">2019-02</a>\r\n"
					+ "				\r\n"
					+ "				<a href=\"2019_03.html\">2019-03</a>\r\n"
					+ "				<a href=\"2019_04.html\">2019-04</a>\r\n"
					+ "				<a href=\"2019_05.html\">2019-05</a>\r\n"
					+ "				<a href=\"2019_06.html\">2019-06</a>\r\n"
					+ "			</div>	\r\n"
					+ "			<div class=\"nav_list\">	\r\n"
					+ "				<a href=\"2019_07.html\">2019-07</a>\r\n"
					+ "				<a href=\"2019_08.html\">2019-08</a>\r\n"
					+ "				<a href=\"2019_09.html\">2019-09</a>\r\n"
					+ "				<a href=\"2019_10.html\">2019-10</a>\r\n"
					+ "				<a href=\"2019_11.html\">2019-11</a>\r\n"
					+ "				<a href=\"2019_12.html\">2019-12</a>\r\n"
					+ "			</div> <!-- END	<div id=\"nav_list\"> -->\r\n"
					+ "		</div> <!-- END of <div id=\"navbar\" class=\"navbar\"> -->\r\n"
					+ "	</div> <!-- END <div id=\"navmenu_div\"> -->");
			
			output.print("<h1 class=\"major_format\">");
			output.println("<!--This is the header of the HTML page-->");
			output.println("Hourly observations for 2019-" + post + "<br>(Wolf Creek Dam, Russell, KY, USA)</h1>");
			output.println("</header>");
			output.println("<hr>");
			output.println("<!--This is the middle of the HTML page below the header that explains the table below-->");
			output.println("<div class=\"major_format\">\r\n"
					+ "		<p>Update Elevation Highlight Threshold:</p>\r\n"
					+ "		<input id=\"newdanger\" type=\"number\">\r\n"
					+ "		<p>Upstream Elevation readings across all 12 pages of hourly readings are highlighted if at or above this threshold value.</p>\r\n"
					+ "		<p>Value should update threshold in some charts on the charts page too.</p>\r\n"
					+ "		<p>Permitted values: [650, ]</p>\r\n"
					+ "		<button id=\"btn_reset_danger\">Reset</button> (Reset Threshold to 720')\r\n"
					+ "	</div>");
			output.println("<hr>");
			
			output.println("<!--This is a button that will be defined later that hides the table when clicked-->");
			output.println("<button class=\"major_format\" id=\"showhide_button\"" + post + "\">Hide Table</button>");
			
			//Print the heading of the page at the top
			output.println("<h2 class=\"major_format\">Gage Readings for 2019-" + post + ": </h2>");

			
			//Using Scanner, set the delimiter pattern to a quote in order to successfully separate the Strings in the input file
			scnr.useDelimiter("\"");
			
			//one contains the first row of information, two the second row, three the third row, four the fourth row
			ArrayList<String> one = new ArrayList<String>();
			ArrayList<String> two = new ArrayList<String>();
			ArrayList<String> three = new ArrayList<String>();
			ArrayList<String> four = new ArrayList<String>();
			
			//Fill up the ArrayLists with the information from the input file
			while(scnr.hasNext()) {
				String first = scnr.next();
				one.add(first);
				String comma = scnr.next();
				String second = scnr.next();
				two.add(second);
				comma = scnr.next();
				String third = scnr.next();
				three.add(third);
				comma = scnr.next();
				String fourth = scnr.next();
				four.add(fourth);
				if(scnr.hasNext() == false) {
					break;
				}
				comma = scnr.next();
			}
			output.println("<!--This is the table that will display all the data shown on the HTML page-->");
			//Create the table holding the information with appropriate headers
			output.println("<table>");
			output.println("<tr>");
			output.println("<th> GAGE TIME<br> UTC (ISO-8601): </th>");
			output.println("<th> ELEVATION<br> UPSTREAM: </th>");
			output.println("<th> ELEVATION<br> DOWNSTREAM: </th>");
			output.println("<th> DISCHARGE<br> HOURLY AVG.: </th>");
			output.println("</tr>");
			output.println("<br>");
			
			i = 0;
			int j = one.size();
			
			//Row by row, print the input file information into the table to the HTML output file
			while(j > 0) {
				output.println("<tr>");
				output.println("<td>" + one.get(i) + "</td>");
				output.println("<td>" + two.get(i) + "</td>");
				output.println("<td>" + three.get(i) + "</td>");
				output.println("<td>" + four.get(i) + "</td>");
				output.println("</tr>");				
				j--;
				i++;
			}
			output.println("</table>");
			output.println("<div class=\"major_format\">");
			output.println("<button>");
			output.println("<!--This is a button that will send the user to the top of the page when clicked-->");
			output.println("<a name=\"top\"> </a>");
			output.println("<a href=\"#top\">Go To Top</a>");
			output.println("</button>");
			output.println("<hr>");
			output.println("<!--This is the copyright message at the bottom of the page-->");;
			output.println("<div id=\"copyright\" class=\"major_format\">");
			output.println("<p>&copy 2023 - Chris Pichler</p></div>");
			//Close the HTML file 
			output.println("</body>");
			output.println("</html>");
			
			
			
			//Close the output file to empty the buffer
			output.close();
			m++;
			
		//Do this 12 times in accordance with the rubric
		}while(m < 13);
	}
}

